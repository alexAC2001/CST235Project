package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
//import javax.faces.view.ViewScoped;

//Annotations
@ManagedBean
//@ViewScoped
public class Orders {

	//New List of type Orders
	// Order is the object and orders is the list.
	List <Order> orders = new ArrayList<Order>(); 
	
	// This default constructor has a predetermined set of data that
	// fills the properties from the Order class.
	public Orders()
	{
		orders.add(new Order("0000", "This is product 1", (float)12.00, 1));
		orders.add(new Order("0001", "This is product 2", (float)13.00, 1));
		orders.add(new Order("0002", "This is product 3", (float)11.50, 3));
		orders.add(new Order("0003", "This is product 4", (float)12.00, 4));
		orders.add(new Order("0004", "This is product 5", (float)12.00, 3));
		orders.add(new Order("0005", "This is product 6", (float)8.75, 1));
		orders.add(new Order("0006", "This is product 7", (float)9.25, 1));
		orders.add(new Order("0007", "This is product 8", (float)11.25, 2));
		orders.add(new Order("0008", "This is product 9", (float)13.50, 1));
		orders.add(new Order("0009", "This is product 10", (float)14.75, 1));
		orders.add(new Order("00010", "This is product 11", (float)10.00, 2));
		orders.add(new Order("00011", "This is product 12", (float)11.00, 1));
		orders.add(new Order("00012", "This is product 13", (float)9.50, 4));
	}

	// Getters and Setters
	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
	
	
}
