package Controllers;

import java.util.HashMap;

// These must be imported so @ManagedBean and @ViewScoped can be used.
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.User;

@ManagedBean
@ViewScoped
// This class will have methods to have actions
// when the user clicks on the page.
public class FormController {	
	
	HashMap<String, String> account = new HashMap<String, String>();
	
	public void onRegister() {
		// This gets the id number/value of this application.
		FacesContext context = FacesContext.getCurrentInstance();
		// This get the user object
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		// The object, user, is placed in a POST request.
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	
		HashMap<String, String> account = new HashMap<String, String>();
		account.put(User.username, User.password);		
	}
	// The method is used to control what happens when the 
	// user clicks the Submit button.
	public String onLogin() {
		// This gets the id number/value of this application.
		FacesContext context = FacesContext.getCurrentInstance();
		// This get the user object
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);

		// The object, user, is placed in a POST request.
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		if(User.username.equals("user2000") && User.password.equals("123"))
		{
			// This line will display the ProductPage.xhtml page.
		   return "ProductPage.xhtml";		
		}
		else
		{
			return "Error.xhtml"; // Go to the error page.
		}
		/*if(User.username.))
		{
			return "ProductPage.xhtml";
		}
		else
		{
			return "Error.xhtml";
		}*/		
		/*if(account.containsKey(username))
		{
			return "ProductPage.xhtml";
		}
		
		if(User.username.equals(account(username)) && User.password.equals(account.password))
		{
			// This line will display the ProductPage.xhtml page.
		   return "ProductPage.xhtml";		
		}
		else
		{
			return "Error.xhtml"; // Go to the error page.
		}*/
	}
	public String onLogout() {			
		return "LoginForm.xhtml"; // Return to the login page.	
	}	
	public String onLoginPage() {		
		return "LoginForm.xhtml"; // Go to the login page.	
	}
	public String onRegisterPage() {		
		return "Registration_Module.xhtml"; // Go to the Register page.	
	}
	public String onMainMenu() {		
		return "MainMenu.xhtml"; // Return to the main menu.	
	}
}
